# chiemekka.com

Personal site. A single narrow column, one typeface, and a small number of
entries: a short introduction, four projects, writing, and a way to get in touch.

The structure, spacing, and typographic proportions follow
[emilkowal.ski](https://emilkowal.ski/), measured rather than approximated: a
692px column with 24px gutters, 128px between header and first section, 116px
between later sections, entries that are title and description with a 4px gap
and a hover fill. All content and identity are Chiemekka's.

## Running it

```bash
npm install
npm start          # http://localhost:8080, reloads on change
npm run build      # writes _site/
```

Node 20 or later.

## Layout

```
src/
  index.njk              homepage
  about.njk              /about/
  404.njk                /404.html
  projects/*.md          one file per project (this is what the homepage lists)
  writing/index.njk      /writing/
  writing/*.md           one file per article
  _includes/
    base.njk             document shell, header, footer
    project.njk          project page layout
    article.njk          article layout
  _data/site.json        name, role, email, default description
  assets/                css, font, favicon (copied as-is)
eleventy.config.js       collections and filters
.pages.yml               Pages CMS edit surface
.github/workflows/       GitHub Pages deployment
```

## How content works

Two collections drive the site. Adding a file is the only step needed:

- **Projects** — `src/projects/<slug>.md`. Front matter: `title`, `summary`
  (the one line on the homepage), `order` (position), `status` (shown under the
  title), and optionally `link` / `linkLabel` for a live product. The body is
  the project page.
- **Writing** — `src/writing/<slug>.md`. Front matter: `title`, `summary`,
  `date`. The body is the article.

Both are ordinary Markdown with front matter, so they can be written by hand or
through the CMS. Templates never need editing to publish.

The writing section is intentionally empty. Nothing is listed until a real
piece exists; the homepage says so rather than showing placeholder entries.

## Design decisions worth knowing

- **One typeface.** Inter (variable, self-hosted, latin subset) stands in for the
  reference's custom sans, which is not available for use. Weight 550 does most
  of the structural work.
- **Body copy is muted**, entry titles are full-strength. That contrast carries
  the hierarchy; there are no cards, shadows, or borders between entries.
- **Hover** gives an entry a soft fill that extends 16px past the text column,
  matching the reference.
- **Article headings are body-sized** at weight 550, as on the reference. The
  space above them marks the section, not a size jump.
- **Article pages have no visible title**, matching the reference; the `h1` is
  present for screen readers and search engines.
- **Dark mode** follows the system setting. There is no toggle, matching the
  reference's behaviour.
- **No analytics, no JavaScript.** The site ships zero client-side JS.

## Colour

| Token | Light | Dark |
|---|---|---|
| `--bg` | `#fdfdfc` | `#111110` |
| `--text` | `#21201c` | `#f2f1ed` |
| `--muted` | `#63635e` | `#a6a29a` |
| `--hover` | `#f5f4f4` | `#1c1b18` |
| `--rule` | `#e9e9e7` | `#2a2925` |

Light values are the reference's own palette; dark values are a warm equivalent.

## Checks run

- `html-validate` over all eight built pages — clean.
- Internal links: 37 checked, none broken.
- Contrast: pass on every page in both themes (WCAG AA).
- Horizontal overflow: none at 320, 390, 768, 1024, 1440.
- One `h1` per page; tab order and focus rings verified.

## Not yet done — requires your action

**1. GitHub repository.** This folder is a local git repository with no remote.
Create the repository (or use the existing one), then:

```bash
git remote add origin git@github.com:<account>/<repo>.git
git push -u origin main
```

**2. GitHub Pages.** In the repository: Settings → Pages → Source → **GitHub
Actions**. The workflow at `.github/workflows/deploy.yml` builds and deploys on
every push to `main`. Nothing is live until that is enabled.

**3. Custom domain.** After the first successful deploy, add `chiemekka.com` as
the custom domain in Pages and create the DNS records GitHub shows you. A
`CNAME` file is not included, because the domain cannot be verified from here.
Do not change DNS until the site has deployed once and you have confirmed the
records.

**3a. If you deploy to a project subpath** (`username.github.io/repo`) instead of
the custom domain, asset and link URLs are root-absolute and will break. Set
`pathPrefix` in `eleventy.config.js` and prefix the asset paths, or keep the
custom domain, which is the intended target.

**4. Pages CMS.** `.pages.yml` describes the edit surface (projects, writing,
site settings). To connect it: sign in at [Pages CMS](https://pagescms.org)
with GitHub, install the app on this repository, and point it at the config.
Until then, editing Markdown files directly works exactly the same way.

Once connected, publishing a post means: add it in the CMS → it commits to
`main` → the Action rebuilds → the site updates. No local build required.

## Heritage

This replaces the previous chiemekka.com, which was a dark, section-based
landing page positioned around MVP consulting. The email address
(`chiemeka@smontech.com`) and the founder-of-Punterise identity are carried over
from it; the service framing, pricing language, and "submit your startup" flow
are deliberately gone.
