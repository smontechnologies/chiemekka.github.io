---
layout: project.njk
title: Retenum
summary: Evidence and decisions, kept across several ventures.
order: 4
status: Live
type: article
description: "Retenum turns an open question into an experiment, preserving the chain from what happened, to what was learned, to what was decided."
link: https://retenum.io
linkLabel: retenum.io
---

## What it is

Retenum turns an unknown into an experiment, then keeps the chain from what
happened, to what was learned, to what was decided.

Across several ventures at once, that makes it possible to see which ones
produced evidence and which ones only produced activity.

## Why it is shaped this way

Slow feedback is the hardest case. When a decision takes months to resolve,
memory quietly rewrites the reasoning behind it, and a portfolio ends up judged
by how busy each venture looks rather than by what any of them established.

Keeping the chain intact means a decision made in March can still be reviewed in
September — against what was actually known in March.

## Where it stands

Live at retenum.io. It is also where I keep my own venture record, which is the
most demanding test I can give it.
