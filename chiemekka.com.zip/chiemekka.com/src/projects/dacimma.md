---
layout: project.njk
title: DACIMMA
summary: Decision software for traders who work from written rules.
order: 2
status: In development
type: article
description: "DACIMMA helps discretionary traders structure their trading rules, monitor setups, record decisions, and evaluate performance against evidence over time."
---

## What it is

DACIMMA takes a trader's written rules, turns them into a versioned model, and
monitors the market against that model while the trader is away. When something
meaningful changes, it says so. When the data cannot settle a question, it says
that instead of guessing.

It does not place trades, recommend positions, or tell anyone when to enter or
exit. The trader keeps the strategy and every decision. DACIMMA keeps the watch.

## Why it is shaped this way

A rules-based trader already has a method. What they usually lack is continuity:
setups form in windows they cannot sit in front of, and the record of what
happened against *their own* rules is scattered across charts, notes and memory.

Re-checking costs the same attention as watching, so most people re-check badly
or not at all. DACIMMA exists to make that record trustworthy enough to review.

## Where it stands

Specification stage. There is no software yet.

The design decisions that matter are already made: deterministic evaluation
where the condition is objective, explicit handling of ambiguity, immutable
model versions, and a decision record captured against a frozen snapshot of the
evidence.

## What it does not claim

No performance claims, anywhere. It does not predict markets, does not promise
profit, and does not treat a favourable outcome as proof of a good decision.

## The open questions

Three things would decide whether this is worth building: whether traders will
commit their rules to writing, whether they will trust automated evaluation of
those rules, and whether market data can be licensed affordably for this kind of
server-side analysis. None of those is settled.
