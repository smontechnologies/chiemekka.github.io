---
layout: project.njk
title: Punterise
summary: Football predictions, recorded and reflected on.
order: 3
status: Live
type: article
description: "Punterise helps football prediction users develop, evaluate and learn from their prediction methods by bringing structure to predictions, results and reflection."
link: https://punterise.com
linkLabel: punterise.com
---

## What it is

People commit to a prediction before kickoff — a pick, a reason, and a
confidence level. After the result, they reflect on what happened and why.

Enough of those cycles and the product can show patterns in how someone decides,
rather than only whether they won.

## Why it is shaped this way

A prediction on its own teaches very little. The same reasoning can produce a
win one week and a loss the next, and if the record is only a score, the
feedback rewards superstition as readily as method.

Punterise keeps the reasoning attached to the outcome, so reflection has
something to work with. The rating is a consequence of the decision, not the
point of it.

## What it does not claim

No guaranteed accuracy, no profit, and no betting advice. The product is about
the quality of the reasoning, not the certainty of the result.
