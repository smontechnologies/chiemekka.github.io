---
layout: project.njk
title: Kazi
summary: Where construction work breaks, and what is worth building.
order: 1
status: Investigation in progress
type: article
description: "Kazi is an investigation into construction workflows: where the work breaks, what the evidence shows, and whether anything is worth building."
---

## What this is

Kazi is an investigation, not a product. It looks at how construction work gets
coordinated in Nigeria — the requests, approvals, quotes and deliveries that move
between site teams, suppliers and clients — and asks where the friction is real
enough to build against.

The output is not a specification. It is a decision about whether to build
anything at all, and if so, what the smallest honest version would be.

## Why it is hard to answer

Construction runs on phone calls, WhatsApp threads and paper. That makes the
workflow easy to describe and difficult to verify. A large share of what looks
like a software problem turns out to be a trust problem, a timing problem, or no
problem at all — just a process that feels messier from the outside than it does
to the people inside it.

So the work is not to design screens. It is to find out which of those three
things I am actually looking at.

## How the investigation is run

Every claim carries a label, and the label decides how much weight it can hold.

- **Fact** — observed or documented, and checkable by someone else.
- **Observation** — seen once. Interesting, not yet generalisable.
- **Assumption** — believed, unverified, and currently doing quiet work.
- **Hypothesis** — stated precisely enough that it could be proven wrong.

The rule is simple: nothing moves from assumption to fact because it sounds
right. It moves when something in the world changes to prove it. Where evidence
is missing, the honest output is "unknown" rather than a plausible guess.

## Where it stands

No validated findings yet. That is not a setback; it is the current state of the
evidence, stated plainly.

What exists so far is a map of the workflow and the decisions inside it. What
does not exist yet is proof that any part of it is painful enough — or expensive
enough — that someone would change how they work to fix it.

## What would change my mind

Two things, mainly. Evidence that the coordination problem is already handled by
tools people genuinely use, in which case there is nothing to build. Or evidence
that the current process costs little enough that the friction is tolerable,
which amounts to the same conclusion.

Either result is useful. Both are cheaper to find than a product.
